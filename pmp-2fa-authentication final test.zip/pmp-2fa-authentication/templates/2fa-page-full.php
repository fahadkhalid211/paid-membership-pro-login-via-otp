<?php
/**
 * Full standalone 2FA page — outputs a complete HTML document.
 * Called by pmp2fa_render_2fa_page() via template_redirect + exit.
 *
 * Variables provided by caller:
 *   $user, $settings, $method, $show_both, $has_phone,
 *   $remember_opt, $expiry, $masked, $otp_length,
 *   $nonce, $cancel_url, $ajax_url, $site_name, $site_url, $logo_url,
 *   $css (string), $js (string)
 *
 * @package PMP_2FA_Authentication
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?php esc_html_e( 'Verify Your Identity', 'pmp-2fa-authentication' ); ?> &mdash; <?php echo esc_html( $site_name ); ?></title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{
	min-height:100vh;
	display:flex;
	flex-direction:column;
	align-items:center;
	justify-content:center;
	background:linear-gradient(135deg,#4f46e5 0%,#6366f1 40%,#818cf8 100%);
	font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;
	padding:24px 16px;
}
.pmp2fa-page-wrap{
	position:relative;
	z-index:1;
	width:100%;
	max-width:440px;
	display:flex;
	flex-direction:column;
	align-items:center;
	gap:20px;
}
.pmp2fa-logo-link{display:block;text-align:center;text-decoration:none}
.pmp2fa-logo-link img{max-height:60px;width:auto}
.pmp2fa-logo-text{font-size:22px;font-weight:800;color:#ffffff;letter-spacing:-0.3px;text-shadow:0 2px 8px rgba(0,0,0,.2)}
<?php echo $css; // phpcs:ignore ?>
</style>
</head>
<body>
<div class="pmp2fa-page-wrap">

	<!-- Logo -->
	<a href="<?php echo esc_url( $site_url ); ?>" class="pmp2fa-logo-link">
		<?php if ( $logo_url ) : ?>
			<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $site_name ); ?>">
		<?php else : ?>
			<span class="pmp2fa-logo-text"><?php echo esc_html( $site_name ); ?></span>
		<?php endif; ?>
	</a>

	<!-- 2FA Card -->
	<div class="pmp2fa-card" style="width:100%">

		<div class="pmp2fa-card__header">
			<div class="pmp2fa-shield" aria-hidden="true">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
			</div>
			<h1 class="pmp2fa-title"><?php esc_html_e( 'Two-Step Verification', 'pmp-2fa-authentication' ); ?></h1>
			<p class="pmp2fa-subtitle" id="pmp2fa-dest-msg">
				<?php /* translators: %s: masked email or phone */ printf( esc_html__( 'A code was sent to %s', 'pmp-2fa-authentication' ), '<strong>' . esc_html( $masked ) . '</strong>' ); ?>
			</p>
		</div>

		<div id="pmp2fa-notice" class="pmp2fa-notice" style="display:none" role="alert" aria-live="polite"></div>

		<?php if ( $show_both && $has_phone ) : ?>
		<div class="pmp2fa-tabs" role="tablist">
			<button type="button" class="pmp2fa-tab<?php echo $method === 'email' ? ' is-active' : ''; ?>" data-method="email" role="tab">&#x2709; <?php esc_html_e( 'Email', 'pmp-2fa-authentication' ); ?></button>
			<button type="button" class="pmp2fa-tab<?php echo $method === 'sms'   ? ' is-active' : ''; ?>" data-method="sms"   role="tab">&#x1F4F1; <?php esc_html_e( 'SMS', 'pmp-2fa-authentication' ); ?></button>
		</div>
		<?php endif; ?>

		<form id="pmp2fa-form" novalidate>
			<input type="hidden" name="action" value="pmp2fa_verify_otp">
			<input type="hidden" name="nonce" value="<?php echo esc_attr( $nonce ); ?>">

			<div class="pmp2fa-field">
				<label for="pmp2fa-otp" class="pmp2fa-label"><?php esc_html_e( 'Verification Code', 'pmp-2fa-authentication' ); ?></label>
				<input
					type="text"
					id="pmp2fa-otp"
					name="otp"
					class="pmp2fa-otp-input"
					inputmode="numeric"
					autocomplete="one-time-code"
					maxlength="<?php echo esc_attr( $otp_length ); ?>"
					placeholder="<?php echo esc_attr( str_repeat( '-', $otp_length ) ); ?>"
					autofocus
					required
				>
				<p class="pmp2fa-hint">
					<?php /* translators: %d: number of minutes */ printf( esc_html( _n( 'Expires in %d minute', 'Expires in %d minutes', $expiry, 'pmp-2fa-authentication' ) ), absint( $expiry ) ); ?>
				</p>
			</div>

			<?php if ( $remember_opt ) : ?>
			<label class="pmp2fa-check-label">
				<input type="checkbox" name="remember_device" value="1">
				<?php /* translators: %d: number of days */ printf( esc_html( _n( 'Trust this device for %d day', 'Trust this device for %d days', (int) $settings['remember_days'], 'pmp-2fa-authentication' ) ), (int) $settings['remember_days'] ); ?>
			</label>
			<?php endif; ?>

			<button type="submit" id="pmp2fa-submit" class="pmp2fa-btn-primary">
				<span class="pmp2fa-btn-text"><?php esc_html_e( 'Verify Code', 'pmp-2fa-authentication' ); ?></span>
				<span class="pmp2fa-spinner" aria-hidden="true"></span>
			</button>
		</form>

		<div style="text-align:center;margin-top:18px">
			<button type="button" id="pmp2fa-resend" class="pmp2fa-link-btn" disabled>
				<?php esc_html_e( 'Resend Code', 'pmp-2fa-authentication' ); ?><span id="pmp2fa-countdown"></span>
			</button>
		</div>

		<div style="text-align:center;margin-top:12px">
			<a href="<?php echo esc_url( $cancel_url ); ?>" class="pmp2fa-back-link">&larr; <?php esc_html_e( 'Cancel &amp; Back to Login', 'pmp-2fa-authentication' ); ?></a>
		</div>

	</div><!-- /.pmp2fa-card -->

	<p style="font-size:12px;color:rgba(255,255,255,0.7);text-align:center">
		<?php /* translators: %s: site name */ printf( esc_html__( 'Secured by PMP 2FA &middot; %s', 'pmp-2fa-authentication' ), esc_html( $site_name ) ); ?>
	</p>

</div><!-- /.pmp2fa-page-wrap -->

<script>
window.pmp2fa_cfg = <?php echo wp_json_encode( array(
	'ajax_url'   => $ajax_url,
	'nonce'      => $nonce,
	'is_overlay' => false,
	'i18n'       => array(
		'verifying'  => __( 'Verifying…',    'pmp-2fa-authentication' ),
		'sending'    => __( 'Sending code…', 'pmp-2fa-authentication' ),
		'verify_btn' => __( 'Verify Code',   'pmp-2fa-authentication' ),
		'resend_btn' => __( 'Resend Code',   'pmp-2fa-authentication' ),
	),
) ); ?>;
</script>
<script><?php echo $js; // phpcs:ignore ?></script>

</body>
</html>
